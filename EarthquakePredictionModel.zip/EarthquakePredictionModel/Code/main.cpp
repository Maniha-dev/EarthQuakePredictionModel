#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <map>
#include <cmath>
#include <iomanip>
#include <limits>
#include <algorithm>
#include <stdexcept>

#ifdef _WIN32
#include <windows.h>
#endif

using namespace std;

// =================== ConsoleColor Class ====================
class ConsoleColor {
public:
    static void setRed() {
#ifdef _WIN32
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
#else
        cout << "\033[1;31m";
#endif
    }
    static void setGreen() {
#ifdef _WIN32
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);
#else
        cout << "\033[1;32m";
#endif
    }
    static void setYellow() {
#ifdef _WIN32
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
#else
        cout << "\033[1;33m";
#endif
    }
    static void setBlue() {
#ifdef _WIN32
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
#else
        cout << "\033[1;34m";
#endif
    }
    static void setCyan() {
#ifdef _WIN32
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 11);
#else
        cout << "\033[1;36m";
#endif
    }
    static void setMagenta() {
#ifdef _WIN32
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 13);
#else
        cout << "\033[1;35m";
#endif
    }
    static void reset() {
#ifdef _WIN32
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 7);
#else
        cout << "\033[0m";
#endif
    }
};

// =================== EarthquakeEvent Class ====================
class EarthquakeEvent {
public:
    string time_str;
    int year;
    double latitude;
    double longitude;
    string province;

    EarthquakeEvent(string t_str, double lat, double lon)
        : time_str(t_str), latitude(lat), longitude(lon) {
        try { year = stoi(t_str.substr(0, 4)); }
        catch (...) { year = 0; }
    }
};

// =================== SeismicDataReader Class ====================
class SeismicDataReader {
public:
    vector<EarthquakeEvent> loadData(const string& filePath) {
        vector<EarthquakeEvent> events;
        ifstream file(filePath);
        string line;

        if (!file.is_open()) throw runtime_error("Could not open file " + filePath);

        getline(file, line);
        stringstream header_ss(line);
        string token;
        vector<string> headers;
        while (getline(header_ss, token, ',')) headers.push_back(token);

        int time_idx = -1, lat_idx = -1, lon_idx = -1;
        for (int i = 0; i < headers.size(); i++) {
            if (headers[i] == "time") time_idx = i;
            else if (headers[i] == "latitude") lat_idx = i;
            else if (headers[i] == "longitude") lon_idx = i;
        }
        if (time_idx == -1 || lat_idx == -1 || lon_idx == -1)
            throw runtime_error("Required columns not found.");

        while (getline(file, line)) {
            stringstream ss(line);
            vector<string> row;
            while (getline(ss, token, ',')) row.push_back(token);
            if (row.size() <= max({time_idx, lat_idx, lon_idx})) continue;
            try {
                string t_str = row[time_idx];
                double lat = stod(row[lat_idx]);
                double lon = stod(row[lon_idx]);
                events.emplace_back(t_str, lat, lon);
            }
            catch (...) { continue; }
        }
        return events;
    }

    void assignProvinces(vector<EarthquakeEvent>& events) {
        map<string, map<string, double>> province_boundaries = {
            {"Balochistan", {{"latitude_min", 24.7}, {"latitude_max", 32.23}, {"longitude_min", 60.64}, {"longitude_max", 70.43}}},
            {"Khyber Pakhtunkhwa", {{"latitude_min", 30.98}, {"latitude_max", 37.11}, {"longitude_min", 68.94}, {"longitude_max", 74.46}}},
            {"Punjab", {{"latitude_min", 27.5}, {"latitude_max", 34.2}, {"longitude_min", 69.12}, {"longitude_max", 75.57}}},
            {"Sindh", {{"latitude_min", 23.45}, {"latitude_max", 28.8}, {"longitude_min", 66.33}, {"longitude_max", 71.29}}}
        };
        for (auto& e : events) {
            bool assigned = false;
            for (auto& p : province_boundaries) {
                auto& b = p.second;
                if (e.latitude >= b["latitude_min"] && e.latitude <= b["latitude_max"]
                    && e.longitude >= b["longitude_min"] && e.longitude <= b["longitude_max"]) {
                    e.province = p.first; assigned = true; break;
                }
            }
            if (!assigned) e.province = "Other";
        }
    }
};

// =================== PoissonCalculator Class ====================
class PoissonCalculator {
private:
    double lambda;
public:
    PoissonCalculator(double avg) : lambda(avg) {}
    double calculateProbability(int k) {
        if (k < 0 || lambda <= 0) return 0.0;
        double log_p = k * log(lambda) - lambda - lgamma(k + 1.0);
        return exp(log_p);
    }
    int predictCount() { return static_cast<int>(round(lambda)); }
};

// =================== EarthquakePredictor Class ====================
class EarthquakePredictor {
public:
    void analyze(const string& title, const map<int, int>& data) {
        if (data.empty()) {
            ConsoleColor::setYellow(); cout << "\n--- " << title << " ---\n";
            ConsoleColor::setRed(); cout << "  No data available.\n"; ConsoleColor::reset();
            return;
        }

        double total = 0;
        for (auto& d : data) total += d.second;

        int years = (data.size() == 1) ? 1 : (data.rbegin()->first - data.begin()->first + 1);
        double lambda = total / years;

        PoissonCalculator p(lambda);
        int predicted = p.predictCount();
        double prob = p.calculateProbability(predicted) * 100;

        ConsoleColor::setCyan(); cout << "\n--- " << title << " ---\n"; ConsoleColor::reset();
        cout << "  Lambda: "; ConsoleColor::setGreen();
        cout << fixed << setprecision(2) << lambda << endl; ConsoleColor::reset();
        cout << "  Predicted Count: "; ConsoleColor::setYellow();
        cout << predicted << endl; ConsoleColor::reset();
        cout << "  Probability of " << predicted << ": "; ConsoleColor::setMagenta();
        cout << fixed << setprecision(4) << prob << "%\n"; ConsoleColor::reset();
    }
};

// =================== Main Program ====================
int main() {
    string filePath;
    ConsoleColor::setYellow();
    cout << "Enter full path to earthquake CSV file: "; ConsoleColor::reset();
    getline(cin, filePath);
    SeismicDataReader reader;

    try {
        ConsoleColor::setCyan(); cout << "Loading data...\n"; ConsoleColor::reset();
        vector<EarthquakeEvent> events = reader.loadData(filePath);
        cout << "Loaded " << events.size() << " events.\n";
        if (events.empty()) throw runtime_error("No data loaded.");
        reader.assignProvinces(events);

        vector<EarthquakeEvent> pakistan_events;
        for (auto& e : events)
            if (e.province != "Other" && e.year != 0)
                pakistan_events.push_back(e);
        if (pakistan_events.empty())
            throw runtime_error("No valid data for Pakistan.");

        map<int, int> overall_data;
        for (auto& e : pakistan_events) overall_data[e.year]++;

        EarthquakePredictor predictor;
        predictor.analyze("Overall Pakistan Prediction", overall_data);

        map<string, map<int, int>> province_data;
        for (auto& e : pakistan_events) province_data[e.province][e.year]++;

        ConsoleColor::setYellow();
        cout << "\nEnter province name (Balochistan, Khyber Pakhtunkhwa, Punjab, Sindh) or 'all': ";
        ConsoleColor::reset();
        string input;
        getline(cin, input);
        transform(input.begin(), input.end(), input.begin(), ::tolower);
        input.erase(remove_if(input.begin(), input.end(), ::isspace), input.end());

        map<string, string> valid = {
            {"balochistan", "Balochistan"}, {"punjab", "Punjab"},
            {"sindh", "Sindh"}, {"khyberpakhtunkhwa", "Khyber Pakhtunkhwa"}
        };

        if (input == "all" || input.empty()) {
            for (auto& p : valid)
                predictor.analyze("Province: " + p.second, province_data[p.second]);
        } else if (valid.find(input) != valid.end()) {
            predictor.analyze("Province: " + valid[input], province_data[valid[input]]);
        } else {
            ConsoleColor::setRed(); cout << "Invalid province entered.\n"; ConsoleColor::reset();
        }
    }
    catch (exception& e) {
        ConsoleColor::setRed(); cerr << "Error: " << e.what() << endl; ConsoleColor::reset();
        return 1;
    }
    ConsoleColor::setGreen(); cout << "\nThank you for using the predictor!\n"; ConsoleColor::reset();
}
